

**** ST-LINK_gdbserver_4.2.5+BlueNRG-TrueSTUDIOv8_1-win32 (): Atollic 8.1.0, BlueNRG-1, BlueNRG-2 patch for STlink GDBserver


To install the new ST-LINK_GDBServer in Atollic, TrueSTUDIO v8.1.0 on Windows follow these steps:

1. Make a backup copy of the following folder:
   C:\Program Files (x86)\Atollic\TrueSTUDIO for ARM 8.1.0\Servers\ST-LINK_gdbserver

2. copy the files on ST-LINK_gdbserver_4.2.5+BlueNRG-TrueSTUDIOv8_1-win32 to
   C:\Program Files (x86)\Atollic\TrueSTUDIO for ARM 8.1.0\Servers\ST-LINK_gdbserver


-----------------------------------------------------------------------------------------------------------------------------------------------------------

NOTE: This patch is valid only for Atollic 8.1.0 available on:

https://atollic.com/release-news/atollic-truestudio-8-1-0-released/

DO not apply it to Atollic v9.0.0 or later.